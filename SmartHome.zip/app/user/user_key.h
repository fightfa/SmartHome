#ifndef __USER_KEY_H__
#define __USER_KEY_H__
//#include "../driver/key.h"
//void user_airkiss_key_init(key_function long_press, key_function short_press);
#endif
